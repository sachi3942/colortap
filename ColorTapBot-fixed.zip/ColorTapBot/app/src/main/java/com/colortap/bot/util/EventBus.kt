package com.colortap.bot.util

import android.os.Handler
import android.os.Looper

/** Simple main-thread event bus so the service can push live log lines / running state to the UI. */
object EventBus {
    private val handler = Handler(Looper.getMainLooper())
    private val listeners = mutableListOf<(String) -> Unit>()
    private val stateListeners = mutableListOf<(Boolean) -> Unit>()
    private val statsListeners = mutableListOf<(String) -> Unit>()

    @Volatile var isRunning: Boolean = false
        private set

    // Color-detect stats (from ScreenCaptureService) and random-clicker stats (from
    // TapAccessibilityService) are independent - each updates its own slot and the combined text
    // is what actually gets pushed to the floating badge, so neither overwrites the other.
    @Volatile private var colorStats: String = ""
    @Volatile private var randomStats: String = ""

    fun addLogListener(l: (String) -> Unit) { listeners.add(l) }
    fun removeLogListener(l: (String) -> Unit) { listeners.remove(l) }

    fun addStateListener(l: (Boolean) -> Unit) { stateListeners.add(l) }
    fun removeStateListener(l: (Boolean) -> Unit) { stateListeners.remove(l) }

    fun addStatsListener(l: (String) -> Unit) { statsListeners.add(l) }
    fun removeStatsListener(l: (String) -> Unit) { statsListeners.remove(l) }

    fun log(msg: String) {
        handler.post { listeners.forEach { it(msg) } }
    }

    /** Kept for compatibility - sets the color-stats slot. */
    fun setStats(text: String) = setColorStats(text)

    fun setColorStats(text: String) {
        colorStats = text
        publishCombinedStats()
    }

    fun setRandomStats(text: String) {
        randomStats = text
        publishCombinedStats()
    }

    fun clearRandomStats() {
        randomStats = ""
        publishCombinedStats()
    }

    fun clearColorStats() {
        colorStats = ""
        publishCombinedStats()
    }

    private fun publishCombinedStats() {
        val combined = listOf(colorStats, randomStats).filter { it.isNotBlank() }.joinToString("\n\n")
        handler.post { statsListeners.forEach { it(combined) } }
    }

    fun setRunning(running: Boolean) {
        isRunning = running
        handler.post { stateListeners.forEach { it(running) } }
    }
}
