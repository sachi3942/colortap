package com.colortap.bot.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.colortap.bot.model.Rule
import com.colortap.bot.util.EventBus
import kotlin.random.Random

class TapAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    // ruleId -> its own repeating random-click Runnable, so each random rule keeps its own
    // independent interval/schedule.
    private val randomRunnables = mutableMapOf<String, Runnable>()
    private val randomTapCounts = mutableMapOf<String, Int>()
    private val randomLastPoint = mutableMapOf<String, IntArray>()
    private val randomRulesById = mutableMapOf<String, Rule>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        EventBus.log("Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* not needed */ }
    override fun onInterrupt() { /* not needed */ }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        stopRandomClicking()
        instance = null
        return super.onUnbind(intent)
    }

    /** Fire [count] taps at (x, y), [intervalMs] apart. */
    fun performTaps(x: Int, y: Int, count: Int, intervalMs: Long) {
        for (i in 0 until count) {
            handler.postDelayed({ dispatchSingleTap(x, y) }, i * intervalMs)
        }
    }

    private fun dispatchSingleTap(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 40)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    /** Starts (or restarts) the random-click loop for every enabled RANDOM rule given. Each rule
     * runs on its own independent timer using its own randomIntervalSec, and every firing picks a
     * fresh random point from that rule's list - no fixed pattern, repeats allowed. */
    fun startRandomClicking(rules: List<Rule>) {
        stopRandomClicking()
        rules.filter { it.type == "RANDOM" && it.enabled && it.randomPoints.isNotEmpty() }
            .forEach { rule ->
                randomRulesById[rule.id] = rule
                randomTapCounts[rule.id] = 0
                scheduleNext(rule)
            }
        publishRandomStats()
    }

    private fun scheduleNext(rule: Rule) {
        val intervalMs = (rule.randomIntervalSec.coerceAtLeast(1)) * 1000L
        val runnable = object : Runnable {
            override fun run() {
                val pts = rule.randomPoints
                if (pts.isNotEmpty()) {
                    val pick = pts[Random.nextInt(pts.size)]
                    dispatchSingleTap(pick[0], pick[1])
                    randomTapCounts[rule.id] = (randomTapCounts[rule.id] ?: 0) + 1
                    randomLastPoint[rule.id] = pick
                    EventBus.log("${rule.name}: random tap at (${pick[0]},${pick[1]})")
                    publishRandomStats()
                }
                handler.postDelayed(this, intervalMs)
            }
        }
        randomRunnables[rule.id] = runnable
        handler.postDelayed(runnable, intervalMs)
    }

    private fun publishRandomStats() {
        if (randomRulesById.isEmpty()) {
            EventBus.clearRandomStats()
            return
        }
        val text = randomRulesById.values.joinToString("\n") { rule ->
            val taps = randomTapCounts[rule.id] ?: 0
            val last = randomLastPoint[rule.id]
            val lastText = if (last != null) "(${last[0]},${last[1]})" else "-"
            "🎲 ${rule.name}: taps:$taps  last:$lastText  every:${rule.randomIntervalSec}s"
        }
        EventBus.setRandomStats(text)
    }

    fun stopRandomClicking() {
        randomRunnables.values.forEach { handler.removeCallbacks(it) }
        randomRunnables.clear()
        randomTapCounts.clear()
        randomLastPoint.clear()
        randomRulesById.clear()
        EventBus.clearRandomStats()
    }

    fun isRandomClickingActive(): Boolean = randomRunnables.isNotEmpty()

    companion object {
        var instance: TapAccessibilityService? = null
            private set

        fun isConnected(): Boolean = instance != null
    }
}
