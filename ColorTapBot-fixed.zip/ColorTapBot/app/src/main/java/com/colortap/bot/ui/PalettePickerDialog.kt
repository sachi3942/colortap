package com.colortap.bot.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.widget.GridLayout
import android.widget.TextView
import com.colortap.bot.R

/**
 * Grid of 18 common preset colors - no RGB sliders. Optionally shows an "eyedropper" button that
 * lets the caller sample the live color at the rule's detect point instead of guessing a swatch.
 */
class PalettePickerDialog(
    context: Context,
    private val title: String = "Pick a color",
    private val showEyedropper: Boolean = false,
    private val onEyedropper: (() -> Unit)? = null,
    private val onPicked: (Int) -> Unit
) : Dialog(context) {

    companion object {
        val PRESETS: List<Pair<String, Int>> = listOf(
            "Red" to Color.parseColor("#FF3B30"),
            "Orange" to Color.parseColor("#FF9500"),
            "Amber" to Color.parseColor("#FFB300"),
            "Yellow" to Color.parseColor("#FFD400"),
            "Lime" to Color.parseColor("#AEEA00"),
            "Green" to Color.parseColor("#34C759"),
            "Teal" to Color.parseColor("#00BFA5"),
            "Cyan" to Color.parseColor("#00E5FF"),
            "Sky" to Color.parseColor("#32ADE6"),
            "Blue" to Color.parseColor("#0A84FF"),
            "Indigo" to Color.parseColor("#5856D6"),
            "Purple" to Color.parseColor("#AF52DE"),
            "Pink" to Color.parseColor("#FF2D92"),
            "Magenta" to Color.parseColor("#E91E8C"),
            "Brown" to Color.parseColor("#8D6E63"),
            "White" to Color.WHITE,
            "Gray" to Color.parseColor("#8E8E93"),
            "Black" to Color.BLACK
        )
    }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_palette_picker, null)
        setContentView(view)
        window?.setBackgroundDrawableResource(android.R.color.transparent)

        view.findViewById<TextView>(R.id.tvTitle).text = title

        val grid = view.findViewById<GridLayout>(R.id.grid)
        val dp = context.resources.displayMetrics.density
        val size = (48 * dp).toInt()
        val margin = (6 * dp).toInt()
        PRESETS.forEach { (_, color) ->
            val dot = View(context)
            val lp = GridLayout.LayoutParams()
            lp.width = size; lp.height = size
            lp.setMargins(margin, margin, margin, margin)
            dot.layoutParams = lp
            val bg = android.graphics.drawable.GradientDrawable()
            bg.shape = android.graphics.drawable.GradientDrawable.OVAL
            bg.setColor(color)
            bg.setStroke(3, Color.parseColor("#2E3358"))
            dot.background = bg
            dot.setOnClickListener { onPicked(color); dismiss() }
            grid.addView(dot)
        }

        val eyedropperBtn = view.findViewById<TextView>(R.id.btnEyedropper)
        if (showEyedropper && onEyedropper != null) {
            eyedropperBtn.visibility = View.VISIBLE
            eyedropperBtn.setOnClickListener { onEyedropper.invoke(); dismiss() }
        }

        view.findViewById<View>(R.id.btnCancel).setOnClickListener { dismiss() }
    }
}
