package com.colortap.bot.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.colortap.bot.R
import com.colortap.bot.model.Rule
import com.colortap.bot.service.PointPickerOverlayService
import com.colortap.bot.service.ScreenCaptureService
import com.colortap.bot.util.PrefsManager

class RuleEditActivity : AppCompatActivity() {

    private lateinit var rule: Rule
    private lateinit var rules: MutableList<Rule>

    private lateinit var rowTargetColors: LinearLayout
    private lateinit var swatchReset: View
    private lateinit var tvDetectPoint: TextView
    private lateinit var tvTapPoint: TextView
    private lateinit var rowRandomPoints: LinearLayout

    private lateinit var stepperRequired: Stepper
    private lateinit var stepperNormalTaps: Stepper
    private lateinit var stepperEscalatedTaps: Stepper
    private lateinit var stepperTapInterval: Stepper
    private lateinit var stepperRandomInterval: Stepper

    private var pickingMode: String? = null

    private val pointReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val x = intent?.getIntExtra("x", -1) ?: -1
            val y = intent?.getIntExtra("y", -1) ?: -1
            val mode = intent?.getStringExtra("mode") ?: return
            when (mode) {
                "detect" -> { rule.detectX = x; rule.detectY = y; tvDetectPoint.text = "x=$x, y=$y" }
                "tap" -> { rule.tapX = x; rule.tapY = y; tvTapPoint.text = "x=$x, y=$y" }
                "random_point" -> { rule.randomPoints.add(intArrayOf(x, y)); renderRandomPoints() }
            }
            pickingMode = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rule_edit)

        rules = PrefsManager.loadRules(this)
        val ruleId = intent.getStringExtra("ruleId")
        rule = rules.find { it.id == ruleId } ?: Rule().also { rules.add(it) }

        findViewById<EditText>(R.id.etName).setText(rule.name)
        rowTargetColors = findViewById(R.id.rowTargetColors)
        swatchReset = findViewById(R.id.swatchReset)
        tvDetectPoint = findViewById(R.id.tvDetectPoint)
        tvTapPoint = findViewById(R.id.tvTapPoint)
        rowRandomPoints = findViewById(R.id.rowRandomPoints)

        val sectionColor = findViewById<View>(R.id.sectionColor)
        val sectionRandom = findViewById<View>(R.id.sectionRandom)
        if (rule.type == "RANDOM") {
            sectionColor.visibility = View.GONE
            sectionRandom.visibility = View.VISIBLE
        } else {
            sectionColor.visibility = View.VISIBLE
            sectionRandom.visibility = View.GONE
        }

        renderTargetColors()
        renderResetSwatch()
        renderPoints()
        renderRandomPoints()

        stepperRequired = Stepper(findViewById(R.id.stepperRequired), rule.requiredCount.toLong(), 1, 999, 1) {}
        stepperNormalTaps = Stepper(findViewById(R.id.stepperNormalTaps), rule.normalTapCount.toLong(), 1, 20, 1) {}
        stepperEscalatedTaps = Stepper(findViewById(R.id.stepperEscalatedTaps), rule.escalatedTapCount.toLong(), 1, 20, 1) {}
        stepperTapInterval = Stepper(findViewById(R.id.stepperTapInterval), rule.tapIntervalMs, 20, 3000, 20) {}
        stepperRandomInterval = Stepper(findViewById(R.id.stepperRandomInterval), rule.randomIntervalSec.toLong(), 1, 100, 1) {}

        val seekTolerance = findViewById<SeekBar>(R.id.seekTolerance)
        val tvTolerance = findViewById<TextView>(R.id.tvTolerance)
        seekTolerance.progress = rule.tolerance
        tvTolerance.text = rule.tolerance.toString()
        seekTolerance.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { tvTolerance.text = p.toString() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<View>(R.id.btnPickDetect).setOnClickListener { startPicking("detect") }
        findViewById<View>(R.id.btnPickTap).setOnClickListener { startPicking("tap") }
        findViewById<View>(R.id.btnAddRandomPoint).setOnClickListener { startPicking("random_point") }
        findViewById<View>(R.id.btnPickReset).setOnClickListener {
            PalettePickerDialog(
                this,
                title = "Reset color එක තෝරන්න",
                showEyedropper = true,
                onEyedropper = { pickLiveResetColor() }
            ) { c ->
                rule.resetColor = c; renderResetSwatch()
            }.show()
        }
        findViewById<View>(R.id.btnClearReset).setOnClickListener {
            rule.resetColor = null; renderResetSwatch()
        }

        findViewById<View>(R.id.btnSave).setOnClickListener { save(seekTolerance.progress) }

        LocalBroadcastManager.getInstance(this)
            .registerReceiver(pointReceiver, IntentFilter(PointPickerOverlayService.ACTION_POINT_PICKED))
    }

    override fun onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(pointReceiver)
        super.onDestroy()
    }

    private fun pickLiveTargetColor() {
        pickLiveColor { hex, color ->
            rule.targetColors.add(color)
            renderTargetColors()
            Toast.makeText(this, "Live color ($hex) target එකට එකතු කරා", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickLiveResetColor() {
        pickLiveColor { hex, color ->
            rule.resetColor = color
            renderResetSwatch()
            Toast.makeText(this, "Live color ($hex) reset color විදිහට set කරා", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickLiveColor(onColor: (hex: String, color: Int) -> Unit) {
        if (rule.detectX < 0 || rule.detectY < 0) {
            Toast.makeText(this, "මුලින්ම Detect point එක set කරන්න", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "Sampling... (automation එකක් run වෙන්නම ඕන)", Toast.LENGTH_SHORT).show()

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                LocalBroadcastManager.getInstance(this@RuleEditActivity).unregisterReceiver(this)
                val success = intent?.getBooleanExtra("success", false) ?: false
                if (success) {
                    val hex = intent?.getStringExtra("color") ?: return
                    onColor(hex, Color.parseColor(hex))
                } else {
                    val reason = intent?.getStringExtra("reason") ?: "Failed"
                    Toast.makeText(this@RuleEditActivity, "$reason - master switch එක on කරලා capture run කරද්දි try කරන්න", Toast.LENGTH_LONG).show()
                }
            }
        }
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(receiver, IntentFilter(ScreenCaptureService.ACTION_PIXEL_RESULT))

        val req = Intent(ScreenCaptureService.ACTION_SAMPLE_PIXEL_REQUEST)
        req.putExtra("x", rule.detectX)
        req.putExtra("y", rule.detectY)
        LocalBroadcastManager.getInstance(this).sendBroadcast(req)
    }

    private fun startPicking(mode: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission එක මුලින්ම දෙන්න", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        pickingMode = mode
        Toast.makeText(this, "ඕනෑම app එකකට ගිහින් තිත draggable මාක් එක තියන්න, පස්සේ Set එබන්න", Toast.LENGTH_LONG).show()
        val i = Intent(this, PointPickerOverlayService::class.java)
        i.putExtra(PointPickerOverlayService.EXTRA_MODE, mode)
        i.putExtra(PointPickerOverlayService.EXTRA_RULE_ID, rule.id)
        startService(i)
    }

    private fun renderTargetColors() {
        rowTargetColors.removeAllViews()
        rule.targetColors.forEachIndexed { index, color ->
            rowTargetColors.addView(makeSwatch(color, removable = true) {
                rule.targetColors.removeAt(index)
                renderTargetColors()
            })
        }
        rowTargetColors.addView(makeAddButton {
            PalettePickerDialog(
                this,
                title = "Count/Target color එක තෝරන්න",
                showEyedropper = true,
                onEyedropper = { pickLiveTargetColor() }
            ) { c ->
                rule.targetColors.add(c)
                renderTargetColors()
            }.show()
        })
    }

    private fun makeSwatch(color: Int, removable: Boolean, onClick: () -> Unit): View {
        val size = (40 * resources.displayMetrics.density).toInt()
        val v = View(this)
        val lp = LinearLayout.LayoutParams(size, size)
        lp.marginEnd = (10 * resources.displayMetrics.density).toInt()
        v.layoutParams = lp
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(color)
        bg.setStroke(3, Color.parseColor(if (removable) "#FF6B6B" else "#2E3358"))
        v.background = bg
        v.setOnClickListener { onClick() }
        return v
    }

    private fun makeAddButton(onClick: () -> Unit): View {
        val size = (40 * resources.displayMetrics.density).toInt()
        val tv = TextView(this)
        tv.layoutParams = LinearLayout.LayoutParams(size, size)
        tv.text = "+"
        tv.gravity = android.view.Gravity.CENTER
        tv.textSize = 18f
        tv.setTextColor(Color.WHITE)
        tv.background = androidx.core.content.ContextCompat.getDrawable(this, R.drawable.bg_pill_accent)
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun renderResetSwatch() {
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(rule.resetColor ?: Color.parseColor("#00000000"))
        bg.setStroke(2, Color.parseColor("#2E3358"))
        swatchReset.background = bg
    }

    private fun renderPoints() {
        tvDetectPoint.text = if (rule.detectX >= 0) "x=${rule.detectX}, y=${rule.detectY}" else "Not set"
        tvTapPoint.text = if (rule.tapX >= 0) "x=${rule.tapX}, y=${rule.tapY}" else "Not set"
    }

    private fun renderRandomPoints() {
        rowRandomPoints.removeAllViews()
        rule.randomPoints.forEachIndexed { index, p ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = android.view.Gravity.CENTER_VERTICAL
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = (6 * resources.displayMetrics.density).toInt()
            row.layoutParams = lp
            row.background = androidx.core.content.ContextCompat.getDrawable(this, R.drawable.bg_card_inner)
            row.setPadding(20, 16, 20, 16)

            val tv = TextView(this)
            tv.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            tv.text = "📍 ස්ථානය ${index + 1}:  x=${p[0]}, y=${p[1]}"
            tv.setTextColor(resources.getColor(R.color.text_primary, theme))
            tv.textSize = 13f
            row.addView(tv)

            val del = TextView(this)
            del.text = "✕"
            del.setTextColor(Color.parseColor("#FF6B6B"))
            del.setPadding(20, 0, 4, 0)
            del.setOnClickListener {
                rule.randomPoints.removeAt(index)
                renderRandomPoints()
            }
            row.addView(del)

            rowRandomPoints.addView(row)
        }
    }

    private fun save(tolerance: Int) {
        rule.name = findViewById<EditText>(R.id.etName).text.toString().ifBlank {
            if (rule.type == "RANDOM") "Random Clicker" else "Rule"
        }

        if (rule.type == "RANDOM") {
            rule.randomIntervalSec = stepperRandomInterval.get().toInt()
            if (rule.randomPoints.isEmpty()) {
                Toast.makeText(this, "අඩුම තරමින් ස්ථානයක් එකතු කරන්න", Toast.LENGTH_SHORT).show()
                return
            }
        } else {
            rule.requiredCount = stepperRequired.get().toInt()
            rule.normalTapCount = stepperNormalTaps.get().toInt()
            rule.escalatedTapCount = stepperEscalatedTaps.get().toInt()
            rule.tapIntervalMs = stepperTapInterval.get()
            rule.tolerance = tolerance

            if (rule.targetColors.isEmpty()) {
                Toast.makeText(this, "අඩුම තරමින් target color එකක් එකතු කරන්න", Toast.LENGTH_SHORT).show()
                return
            }
            if (rule.detectX < 0 || rule.tapX < 0) {
                Toast.makeText(this, "Detection point සහ Tap point දෙකම set කරන්න", Toast.LENGTH_SHORT).show()
                return
            }
        }

        if (rules.none { it.id == rule.id }) rules.add(rule)
        PrefsManager.saveRules(this, rules)
        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        finish()
    }
}
