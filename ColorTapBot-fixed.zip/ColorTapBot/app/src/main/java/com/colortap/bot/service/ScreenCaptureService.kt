package com.colortap.bot.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.colortap.bot.R
import com.colortap.bot.model.Rule
import com.colortap.bot.model.RuleState
import com.colortap.bot.ui.MainActivity
import com.colortap.bot.util.EventBus
import com.colortap.bot.util.PrefsManager

class ScreenCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private val ruleStates = mutableMapOf<String, RuleState>()
    private var running = false

    private val pixelSampleReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val x = intent?.getIntExtra("x", -1) ?: -1
            val y = intent?.getIntExtra("y", -1) ?: -1
            val result = Intent(ACTION_PIXEL_RESULT)
            val reader = imageReader
            if (!running || reader == null) {
                result.putExtra("success", false)
                result.putExtra("reason", "Capture not running")
            } else {
                val hex = readPixelHex(reader, x, y)
                if (hex != null) {
                    result.putExtra("success", true)
                    result.putExtra("color", hex)
                } else {
                    result.putExtra("success", false)
                    result.putExtra("reason", "Sample failed")
                }
            }
            LocalBroadcastManager.getInstance(this@ScreenCaptureService).sendBroadcast(result)
        }
    }

    override fun onCreate() {
        super.onCreate()
        EventBus.log("ScreenCaptureService.onCreate")
        ensureForeground()
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(pixelSampleReceiver, android.content.IntentFilter(ACTION_SAMPLE_PIXEL_REQUEST))
    }

    private fun readPixelHex(reader: ImageReader, x: Int, y: Int): String? {
        val image = try { reader.acquireLatestImage() } catch (e: Exception) { null } ?: return null
        try {
            if (x < 0 || y < 0 || x >= image.width || y >= image.height) return null
            val plane = image.planes[0]
            val buffer = plane.buffer
            val offset = y * plane.rowStride + x * plane.pixelStride
            if (offset + 3 >= buffer.capacity()) return null
            val r = buffer.get(offset).toInt() and 0xFF
            val g = buffer.get(offset + 1).toInt() and 0xFF
            val b = buffer.get(offset + 2).toInt() and 0xFF
            return String.format("#%02X%02X%02X", r, g, b)
        } finally {
            image.close()
        }
    }

    private fun ensureForeground() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                androidx.core.app.ServiceCompat.startForeground(
                    this, NOTIF_ID, buildNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIF_ID, buildNotification())
            }
        } catch (e: Exception) {
            reportFailure("startForeground failed", e)
            stopSelf()
        }
    }

    private fun reportFailure(context: String, e: Exception) {
        val msg = "$context: ${e.javaClass.simpleName}: ${e.message}"
        EventBus.log(msg)
        Handler(mainLooper).post {
            android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        EventBus.log("onStartCommand action=${intent?.action}")
        ensureForeground()
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            return START_NOT_STICKY
        }
        // BUG (root cause of every earlier "start does nothing" failure): Activity.RESULT_OK is
        // itself -1, and -1 was also being used as the "extra not present" sentinel below - so a
        // successfully granted permission (resultCode == RESULT_OK == -1) was indistinguishable
        // from "no extra was passed at all", and this always took the skip branch. Int.MIN_VALUE
        // can never collide with a real Activity result code, so it's safe as the sentinel.
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        EventBus.log("resultCode=$resultCode data=${if (data != null) "present" else "NULL"} running=$running")
        if (data != null && resultCode != Int.MIN_VALUE) {
            startCapture(resultCode, data)
        } else {
            EventBus.log("Skipping start - missing resultCode/data in intent extras")
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val channelId = "colortap_capture"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            if (mgr.getNotificationChannel(channelId) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(channelId, "ColorTap Bot", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("ColorTap Bot ක්‍රියාත්මකයි")
            .setContentText("Color detection running in background")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        if (running) return
        try {
            startCaptureInternal(resultCode, data)
        } catch (e: Exception) {
            reportFailure("Screen capture failed to start", e)
            EventBus.setRunning(false)
            stopSelf()
        }
    }

    private fun startCaptureInternal(resultCode: Int, data: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(resultCode, data)
        if (mediaProjection == null) {
            // Grant token wasn't valid (e.g. stale/expired, or process was killed between the
            // system dialog and this call) - fail loudly instead of silently sitting idle.
            val msg = "MediaProjection token invalid - please grant screen capture again"
            EventBus.log(msg)
            Handler(mainLooper).post { android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show() }
            EventBus.setRunning(false)
            stopSelf()
            return
        }

        // Android 14+ (API 34) requires a registered callback BEFORE createVirtualDisplay(),
        // otherwise the projection silently fails / throws IllegalStateException.
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                val msg = "MediaProjection stopped by system (revoked/expired)"
                EventBus.log(msg)
                Handler(mainLooper).post { android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show() }
                stopCapture()
            }
        }, Handler(mainLooper))

        val metrics = DisplayMetrics()
        // WindowManager.defaultDisplay throws UnsupportedOperationException when called from a
        // Service (a non-visual Context) on API 30+. DisplayManager has no such restriction.
        val dm = getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
        val display = dm.getDisplay(android.view.Display.DEFAULT_DISPLAY)
        @Suppress("DEPRECATION")
        display.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ColorTapCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        ruleStates.clear()
        PrefsManager.loadRules(this).filter { it.enabled && it.type != "RANDOM" }.forEach { r ->
            ruleStates[r.id] = RuleState(r)
        }

        thread = HandlerThread("ColorTapSampler").also { it.start() }
        handler = Handler(thread!!.looper)
        running = true
        EventBus.setRunning(true)
        EventBus.log("Screen capture started (${width}x$height)")
        if (android.provider.Settings.canDrawOverlays(this)) {
            startService(Intent(this, StatsOverlayService::class.java))
        }
        scheduleSample()
    }

    private fun scheduleSample() {
        if (!running) return
        val interval = PrefsManager.globalSampleIntervalMs(this)
        handler?.postDelayed({
            sampleOnce()
            scheduleSample()
        }, interval)
    }

    private val lastColorHex = mutableMapOf<String, String>()

    private fun sampleOnce() {
        val reader = imageReader ?: return
        val image = try { reader.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val width = image.width

            for (state in ruleStates.values) {
                val rule = state.rule
                if (rule.detectX < 0 || rule.detectY < 0) continue
                if (rule.detectX >= image.width || rule.detectY >= image.height) continue
                val offset = rule.detectY * rowStride + rule.detectX * pixelStride
                if (offset + 3 >= buffer.capacity()) continue
                val r = buffer.get(offset).toInt() and 0xFF
                val g = buffer.get(offset + 1).toInt() and 0xFF
                val b = buffer.get(offset + 2).toInt() and 0xFF
                val color = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                lastColorHex[rule.id] = String.format("#%02X%02X%02X", r, g, b)

                val action = state.onColorSampled(color)
                EventBus.log("${rule.name}: ${state.progressText}")
                if (action != null) {
                    EventBus.log(">> TAP x${action.tapCount} at (${action.x},${action.y}) [${rule.name}]")
                    TapAccessibilityService.instance?.performTaps(action.x, action.y, action.tapCount, action.intervalMs)
                        ?: EventBus.log("Accessibility service not enabled - cannot tap!")
                }
            }
            publishStats()
        } catch (e: Exception) {
            EventBus.log("Sample error: ${e.message}")
        } finally {
            image.close()
        }
    }

    private fun publishStats() {
        if (ruleStates.isEmpty()) {
            EventBus.setStats("No active rules")
            return
        }
        val text = ruleStates.values.joinToString("\n") { s ->
            val seen = lastColorHex[s.rule.id] ?: "-"
            val target = s.rule.targetColors.firstOrNull()?.let { String.format("#%02X%02X%02X", (it shr 16) and 0xFF, (it shr 8) and 0xFF, it and 0xFF) } ?: "-"
            "${s.rule.name}: ${s.progressText}  •  taps:${s.totalTaps}\nseen:$seen  target:$target  tol:${s.rule.tolerance}"
        }
        EventBus.setStats(text)
    }

    private fun stopCapture() {
        running = false
        EventBus.setRunning(false)
        EventBus.clearColorStats()
        EventBus.log("Screen capture stopped")
        handler?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        // NOTE: intentionally NOT stopping StatsOverlayService here - it stays visible as a
        // persistent floating "▶ Start" launcher (see StatsOverlayService's stateListener) so the
        // user can restart automation directly from the floating badge without opening the app.
        androidx.core.app.ServiceCompat.stopForeground(this, androidx.core.app.ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) stopCapture()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(pixelSampleReceiver)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    companion object {
        const val NOTIF_ID = 4201
        const val ACTION_STOP = "com.colortap.bot.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val ACTION_SAMPLE_PIXEL_REQUEST = "com.colortap.bot.SAMPLE_PIXEL_REQUEST"
        const val ACTION_PIXEL_RESULT = "com.colortap.bot.SAMPLE_PIXEL_RESULT"
    }
}
