package com.colortap.bot.util

import android.app.Application
import android.content.Context

/**
 * Installs a process-wide uncaught exception handler that writes the crash to SharedPreferences
 * BEFORE the process dies. Any exception thrown asynchronously by the OS (foreground-service
 * timeouts, watchdog kills, etc.) is invisible to a local try/catch inside a Service - this is
 * the only way to reliably see what actually killed the process.
 */
class BotApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sb = StringBuilder()
                sb.append(throwable.javaClass.name).append(": ").append(throwable.message).append("\n")
                throwable.stackTrace.take(8).forEach { sb.append("  at ").append(it).append("\n") }
                var cause = throwable.cause
                var depth = 0
                while (cause != null && depth < 2) {
                    sb.append("Caused by: ").append(cause.javaClass.name).append(": ").append(cause.message).append("\n")
                    cause = cause.cause
                    depth++
                }
                getSharedPreferences("crash_log", Context.MODE_PRIVATE)
                    .edit()
                    .putString("last_crash", sb.toString())
                    .putLong("last_crash_time", System.currentTimeMillis())
                    .commit() // synchronous - must land before process dies
            } catch (_: Throwable) {
                // never let the handler itself throw
            }
            prev?.uncaughtException(thread, throwable)
        }
    }

    companion object {
        /** Call once from MainActivity.onCreate/onResume to surface any pending crash into the log. */
        fun drainLastCrash(context: Context) {
            val prefs = context.getSharedPreferences("crash_log", Context.MODE_PRIVATE)
            val crash = prefs.getString("last_crash", null) ?: return
            val time = prefs.getLong("last_crash_time", 0L)
            prefs.edit().remove("last_crash").remove("last_crash_time").apply()
            EventBus.log("=== App/process crashed ${System.currentTimeMillis() - time}ms ago ===")
            crash.lines().forEach { EventBus.log(it) }
        }
    }
}
