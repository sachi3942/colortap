package com.colortap.bot.service

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import com.colortap.bot.ui.MainActivity
import com.colortap.bot.util.EventBus

/**
 * Small draggable floating badge. When automation isn't running it shows a ▶ Start button that
 * jumps back into the app and auto-triggers the master switch. Once running, it shows each
 * active rule's live "count / required" progress and total taps fired so far.
 */
class StatsOverlayService : Service() {

    private lateinit var wm: WindowManager
    private var view: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var isRunning = false

    private val statsListener: (String) -> Unit = { text ->
        if (isRunning) view?.text = text
    }

    private val stateListener: (Boolean) -> Unit = { running ->
        isRunning = running
        if (!running) view?.text = "▶  Start ColorTap Bot"
    }

    private val overlayType =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        isRunning = EventBus.isRunning
        showOverlay()
        EventBus.addStatsListener(statsListener)
        EventBus.addStateListener(stateListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun showOverlay() {
        val tv = TextView(this).apply {
            text = if (isRunning) "ColorTap Bot" else "▶  Start ColorTap Bot"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(20, 14, 20, 14)
            background = GradientDrawable().apply {
                cornerRadius = 24f
                setColor(Color.parseColor("#CC1B1B2A"))
                setStroke(2, Color.parseColor("#7C5CFF"))
            }
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 24
        lp.y = 160

        var startRawX = 0f; var startRawY = 0f; var startX = 0; var startY = 0
        var moved = false
        tv.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = ev.rawX; startRawY = ev.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                    false // let click also fire
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - startRawX).toInt()
                    val dy = (ev.rawY - startRawY).toInt()
                    if (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12) {
                        moved = true
                        lp.x = startX + dx
                        lp.y = startY + dy
                        runCatching { wm.updateViewLayout(tv, lp) }
                    }
                    moved
                }
                else -> false
            }
        }
        tv.setOnClickListener {
            if (!moved) {
                if (!isRunning) {
                    val i = Intent(this, MainActivity::class.java)
                    i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    i.putExtra(MainActivity.EXTRA_AUTO_START, true)
                    startActivity(i)
                } else {
                    val i = Intent(this, MainActivity::class.java)
                    i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    startActivity(i)
                }
            }
        }

        runCatching { wm.addView(tv, lp) }
        view = tv
        params = lp
    }

    override fun onDestroy() {
        EventBus.removeStatsListener(statsListener)
        EventBus.removeStateListener(stateListener)
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
