package com.colortap.bot.service

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.localbroadcastmanager.content.LocalBroadcastManager

/**
 * Shows a small draggable crosshair marker on top of every app so the user can point at the
 * exact spot to watch / tap, then confirm with the floating "Set" button.
 */
class PointPickerOverlayService : Service() {

    private lateinit var wm: WindowManager
    private var markerView: View? = null
    private var confirmView: View? = null
    private var markerParams: WindowManager.LayoutParams? = null
    private var mode: String = "detect"
    private var ruleId: String = ""

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mode = intent?.getStringExtra(EXTRA_MODE) ?: "detect"
        ruleId = intent?.getStringExtra(EXTRA_RULE_ID) ?: ""
        showOverlay()
        return START_NOT_STICKY
    }

    private val overlayType =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showOverlay() {
        removeViews()

        val size = 72
        val marker = FrameLayout(this).apply {
            background = crosshairDrawable()
        }
        val mParams = WindowManager.LayoutParams(
            size, size,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        mParams.gravity = Gravity.TOP or Gravity.START
        mParams.x = resources.displayMetrics.widthPixels / 2 - size / 2
        mParams.y = resources.displayMetrics.heightPixels / 2 - size / 2

        var startRawX = 0f; var startRawY = 0f; var startX = 0; var startY = 0
        marker.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = ev.rawX; startRawY = ev.rawY
                    startX = mParams.x; startY = mParams.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    mParams.x = startX + (ev.rawX - startRawX).toInt()
                    mParams.y = startY + (ev.rawY - startRawY).toInt()
                    wm.updateViewLayout(marker, mParams)
                    true
                }
                else -> false
            }
        }

        wm.addView(marker, mParams)
        markerView = marker
        markerParams = mParams

        val confirm = TextView(this).apply {
            text = if (mode == "tap") "  ✓ Set TAP point  " else "  ✓ Set DETECT point  "
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#7C5CFF"))
            textSize = 14f
            setPadding(24, 16, 24, 16)
            setOnClickListener {
                val cx = mParams.x + size / 2
                val cy = mParams.y + size / 2 + statusBarOffset()
                val result = Intent(ACTION_POINT_PICKED)
                result.putExtra("x", cx)
                result.putExtra("y", cy)
                result.putExtra("mode", mode)
                result.putExtra("ruleId", ruleId)
                LocalBroadcastManager.getInstance(this@PointPickerOverlayService).sendBroadcast(result)
                stopSelf()
            }
        }
        val cParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        cParams.gravity = Gravity.TOP or Gravity.START
        cParams.x = 40
        cParams.y = 120
        wm.addView(confirm, cParams)
        confirmView = confirm
    }

    private fun statusBarOffset(): Int = 0

    private fun crosshairDrawable(): android.graphics.drawable.Drawable {
        val d = android.graphics.drawable.GradientDrawable()
        d.shape = android.graphics.drawable.GradientDrawable.OVAL
        d.setColor(Color.parseColor("#5533E6B8"))
        d.setStroke(6, Color.parseColor("#33E6B8"))
        return d
    }

    private fun removeViews() {
        markerView?.let { runCatching { wm.removeView(it) } }
        confirmView?.let { runCatching { wm.removeView(it) } }
        markerView = null
        confirmView = null
    }

    override fun onDestroy() {
        removeViews()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_MODE = "mode"
        const val EXTRA_RULE_ID = "ruleId"
        const val ACTION_POINT_PICKED = "com.colortap.bot.POINT_PICKED"
    }
}
