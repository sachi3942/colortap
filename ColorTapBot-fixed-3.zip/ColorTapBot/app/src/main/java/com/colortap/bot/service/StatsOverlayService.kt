package com.colortap.bot.service

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import com.colortap.bot.util.EventBus

/**
 * Small draggable floating badge that shows each active rule's live "count / required" progress
 * and total taps fired so far. Visible on top of any app while automation is running.
 */
class StatsOverlayService : Service() {

    private lateinit var wm: WindowManager
    private var view: TextView? = null
    private var params: WindowManager.LayoutParams? = null

    private val statsListener: (String) -> Unit = { text ->
        view?.text = text
    }

    private val overlayType =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
        EventBus.addStatsListener(statsListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun showOverlay() {
        val tv = TextView(this).apply {
            text = "ColorTap Bot"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(20, 14, 20, 14)
            background = GradientDrawable().apply {
                cornerRadius = 24f
                setColor(Color.parseColor("#CC1B1B2A"))
                setStroke(2, Color.parseColor("#7C5CFF"))
            }
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 24
        lp.y = 160

        var startRawX = 0f; var startRawY = 0f; var startX = 0; var startY = 0
        tv.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = ev.rawX; startRawY = ev.rawY
                    startX = lp.x; startY = lp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (ev.rawX - startRawX).toInt()
                    lp.y = startY + (ev.rawY - startRawY).toInt()
                    runCatching { wm.updateViewLayout(tv, lp) }
                    true
                }
                else -> false
            }
        }

        runCatching { wm.addView(tv, lp) }
        view = tv
        params = lp
    }

    override fun onDestroy() {
        EventBus.removeStatsListener(statsListener)
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
