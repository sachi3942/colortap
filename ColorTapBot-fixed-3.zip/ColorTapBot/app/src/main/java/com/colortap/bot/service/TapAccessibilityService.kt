package com.colortap.bot.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.colortap.bot.util.EventBus

class TapAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        EventBus.log("Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* not needed */ }
    override fun onInterrupt() { /* not needed */ }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    /** Fire [count] taps at (x, y), [intervalMs] apart. */
    fun performTaps(x: Int, y: Int, count: Int, intervalMs: Long) {
        for (i in 0 until count) {
            handler.postDelayed({ dispatchSingleTap(x, y) }, i * intervalMs)
        }
    }

    private fun dispatchSingleTap(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 40)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    companion object {
        var instance: TapAccessibilityService? = null
            private set

        fun isConnected(): Boolean = instance != null
    }
}
