package com.colortap.bot.util

import android.content.Context
import com.colortap.bot.model.Rule
import org.json.JSONArray

object PrefsManager {
    private const val PREFS = "colortap_prefs"
    private const val KEY_RULES = "rules"
    private const val KEY_GLOBAL_SAMPLE_MS = "global_sample_ms"
    private const val KEY_GLOBAL_TOLERANCE = "global_tolerance"

    fun loadRules(ctx: Context): MutableList<Rule> {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = sp.getString(KEY_RULES, null) ?: return mutableListOf()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<Rule>()
            for (i in 0 until arr.length()) list.add(Rule.fromJson(arr.getJSONObject(i)))
            list
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveRules(ctx: Context, rules: List<Rule>) {
        val arr = JSONArray()
        rules.forEach { arr.put(it.toJson()) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_RULES, arr.toString()).apply()
    }

    fun globalSampleIntervalMs(ctx: Context): Long =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_GLOBAL_SAMPLE_MS, 150L)

    fun setGlobalSampleIntervalMs(ctx: Context, ms: Long) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_GLOBAL_SAMPLE_MS, ms).apply()
    }

    fun globalTolerance(ctx: Context): Int =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_GLOBAL_TOLERANCE, 28)

    fun setGlobalTolerance(ctx: Context, tol: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_GLOBAL_TOLERANCE, tol).apply()
    }
}
