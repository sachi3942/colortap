package com.colortap.bot.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.recyclerview.widget.RecyclerView
import com.colortap.bot.R
import com.colortap.bot.model.Rule
import com.google.android.material.switchmaterial.SwitchMaterial
import android.widget.TextView

class RuleAdapter(
    private val rules: MutableList<Rule>,
    private val onEdit: (Rule) -> Unit,
    private val onDelete: (Rule) -> Unit,
    private val onToggle: (Rule, Boolean) -> Unit
) : RecyclerView.Adapter<RuleAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val swatchRow: LinearLayout = v.findViewById(R.id.swatchRow)
        val tvName: TextView = v.findViewById(R.id.tvName)
        val tvDetail: TextView = v.findViewById(R.id.tvDetail)
        val switchEnabled: SwitchMaterial = v.findViewById(R.id.switchEnabled)
        val btnEdit: TextView = v.findViewById(R.id.btnEdit)
        val btnDelete: TextView = v.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_rule, parent, false)
        return VH(v)
    }

    override fun getItemCount() = rules.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val rule = rules[position]
        holder.tvName.text = rule.name
        val taps = "${rule.normalTapCount}x/${rule.escalatedTapCount}x"
        holder.tvDetail.text = "threshold ${rule.requiredCount} · tap $taps · ${rule.tapIntervalMs}ms gap"

        holder.swatchRow.removeAllViews()
        val ctx = holder.itemView.context
        rule.targetColors.forEach { color ->
            val dot = View(ctx)
            val size = (18 * ctx.resources.displayMetrics.density).toInt()
            val lp = LinearLayout.LayoutParams(size, size)
            lp.marginEnd = (4 * ctx.resources.displayMetrics.density).toInt()
            dot.layoutParams = lp
            val bg = android.graphics.drawable.GradientDrawable()
            bg.shape = android.graphics.drawable.GradientDrawable.OVAL
            bg.setColor(color)
            bg.setStroke(2, android.graphics.Color.parseColor("#2E3358"))
            dot.background = bg
            holder.swatchRow.addView(dot)
        }
        rule.resetColor?.let { color ->
            val dot = View(ctx)
            val size = (18 * ctx.resources.displayMetrics.density).toInt()
            val lp = LinearLayout.LayoutParams(size, size)
            dot.layoutParams = lp
            val bg = android.graphics.drawable.GradientDrawable()
            bg.shape = android.graphics.drawable.GradientDrawable.OVAL
            bg.setColor(color)
            bg.setStroke(3, android.graphics.Color.parseColor("#FF6B6B"))
            dot.background = bg
            holder.swatchRow.addView(dot)
        }

        holder.switchEnabled.setOnCheckedChangeListener(null)
        holder.switchEnabled.isChecked = rule.enabled
        holder.switchEnabled.setOnCheckedChangeListener { _, checked -> onToggle(rule, checked) }

        holder.btnEdit.setOnClickListener { onEdit(rule) }
        holder.btnDelete.setOnClickListener { onDelete(rule) }
    }
}
