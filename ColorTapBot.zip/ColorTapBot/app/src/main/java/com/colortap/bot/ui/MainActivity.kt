package com.colortap.bot.ui

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.colortap.bot.R
import com.colortap.bot.model.Rule
import com.colortap.bot.model.RandomRule
import com.colortap.bot.service.RandomClickService
import com.colortap.bot.service.ScreenCaptureService
import com.colortap.bot.service.TapAccessibilityService
import com.colortap.bot.util.EventBus
import com.colortap.bot.util.PrefsManager
import com.google.android.material.switchmaterial.SwitchMaterial
import android.widget.SeekBar
import android.widget.ScrollView

class MainActivity : AppCompatActivity() {

    private lateinit var rules: MutableList<Rule>
    private lateinit var adapter: RuleAdapter
    private lateinit var switchMaster: SwitchMaterial
    private lateinit var tvMasterStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: ScrollView

    private lateinit var randomRules: MutableList<RandomRule>
    private lateinit var randomAdapter: RandomRuleAdapter
    private lateinit var switchRandomMaster: SwitchMaterial
    private lateinit var tvRandomStatus: TextView

    private val logLines = ArrayDeque<String>()

    private val logListener: (String) -> Unit = { line ->
        logLines.addLast(line)
        if (logLines.size > 120) logLines.removeFirst()
        tvLog.text = logLines.joinToString("\n")
        scrollLog.post { scrollLog.fullScroll(View.FOCUS_DOWN) }
    }
    private val stateListener: (Boolean) -> Unit = { running -> updateMasterUi(running) }
    private val randomStateListener: (Boolean) -> Unit = { running -> updateRandomMasterUi(running) }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK && res.data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java)
            intent.putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, res.resultCode)
            intent.putExtra(ScreenCaptureService.EXTRA_DATA, res.data)
            startForegroundServiceCompat(intent)
        } else {
            Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
            switchMaster.isChecked = false
        }
    }

    private val overlayLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        refreshPermissionRows()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 11)
        }

        tvMasterStatus = findViewById(R.id.tvMasterStatus)
        switchMaster = findViewById(R.id.switchMaster)
        tvLog = findViewById(R.id.tvLog)
        scrollLog = findViewById(R.id.scrollLog)

        rules = PrefsManager.loadRules(this)
        val recycler = findViewById<RecyclerView>(R.id.recyclerRules)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = RuleAdapter(rules,
            onEdit = { rule -> openEditor(rule.id) },
            onDelete = { rule ->
                rules.remove(rule)
                PrefsManager.saveRules(this, rules)
                adapter.notifyDataSetChanged()
                updateEmptyState()
            },
            onToggle = { rule, checked ->
                rule.enabled = checked
                PrefsManager.saveRules(this, rules)
            }
        )
        recycler.adapter = adapter
        updateEmptyState()

        findViewById<View>(R.id.btnAddRule).setOnClickListener {
            val r = Rule()
            r.tolerance = PrefsManager.globalTolerance(this)
            rules.add(r)
            PrefsManager.saveRules(this, rules)
            openEditor(r.id)
        }

        randomRules = PrefsManager.loadRandomRules(this)
        val randomRecycler = findViewById<RecyclerView>(R.id.recyclerRandomRules)
        randomRecycler.layoutManager = LinearLayoutManager(this)
        randomAdapter = RandomRuleAdapter(randomRules,
            onEdit = { r -> openRandomEditor(r.id) },
            onDelete = { r ->
                randomRules.remove(r)
                PrefsManager.saveRandomRules(this, randomRules)
                randomAdapter.notifyDataSetChanged()
                updateRandomEmptyState()
            },
            onToggle = { r, checked ->
                r.enabled = checked
                PrefsManager.saveRandomRules(this, randomRules)
            }
        )
        randomRecycler.adapter = randomAdapter
        updateRandomEmptyState()

        findViewById<View>(R.id.btnAddRandomRule).setOnClickListener {
            val r = RandomRule()
            randomRules.add(r)
            PrefsManager.saveRandomRules(this, randomRules)
            openRandomEditor(r.id)
        }

        switchRandomMaster = findViewById(R.id.switchRandomMaster)
        tvRandomStatus = findViewById(R.id.tvRandomStatus)
        switchRandomMaster.setOnCheckedChangeListener { _, checked ->
            if (checked) startRandomAutomation() else stopRandomAutomation()
        }

        setupPermissionRow(R.id.rowAccessibility, "Accessibility service (tap)") { openAccessibilitySettings() }
        setupPermissionRow(R.id.rowOverlay, "Overlay (pointer placement)") { requestOverlayPermission() }
        setupPermissionRow(R.id.rowCapture, "Screen capture") {
            Toast.makeText(this, "Use the master switch to start capture", Toast.LENGTH_SHORT).show()
        }

        val seek = findViewById<SeekBar>(R.id.seekSampleMs)
        val tvSampleMs = findViewById<TextView>(R.id.tvSampleMs)
        val currentMs = PrefsManager.globalSampleIntervalMs(this).toInt()
        seek.progress = (currentMs - 50).coerceIn(0, 950)
        tvSampleMs.text = "$currentMs ms"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val ms = (progress + 50).toLong()
                tvSampleMs.text = "$ms ms"
                if (fromUser) PrefsManager.setGlobalSampleIntervalMs(this@MainActivity, ms)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        switchMaster.setOnCheckedChangeListener { _, checked ->
            if (checked) startAutomation() else stopAutomation()
        }

        EventBus.addLogListener(logListener)
        EventBus.addStateListener(stateListener)
        EventBus.addRandomStateListener(randomStateListener)
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionRows()
        rules = PrefsManager.loadRules(this)
        adapter = RuleAdapter(rules,
            onEdit = { rule -> openEditor(rule.id) },
            onDelete = { rule ->
                rules.remove(rule); PrefsManager.saveRules(this, rules)
                adapter.notifyDataSetChanged(); updateEmptyState()
            },
            onToggle = { rule, checked -> rule.enabled = checked; PrefsManager.saveRules(this, rules) }
        )
        findViewById<RecyclerView>(R.id.recyclerRules).adapter = adapter
        updateEmptyState()
        updateMasterUi(EventBus.isRunning)

        randomRules = PrefsManager.loadRandomRules(this)
        randomAdapter = RandomRuleAdapter(randomRules,
            onEdit = { r -> openRandomEditor(r.id) },
            onDelete = { r ->
                randomRules.remove(r); PrefsManager.saveRandomRules(this, randomRules)
                randomAdapter.notifyDataSetChanged(); updateRandomEmptyState()
            },
            onToggle = { r, checked -> r.enabled = checked; PrefsManager.saveRandomRules(this, randomRules) }
        )
        findViewById<RecyclerView>(R.id.recyclerRandomRules).adapter = randomAdapter
        updateRandomEmptyState()
        updateRandomMasterUi(EventBus.isRandomRunning)
    }

    override fun onDestroy() {
        EventBus.removeLogListener(logListener)
        EventBus.removeStateListener(stateListener)
        EventBus.removeRandomStateListener(randomStateListener)
        super.onDestroy()
    }

    private fun openRandomEditor(ruleId: String) {
        val i = Intent(this, RandomRuleEditActivity::class.java)
        i.putExtra("ruleId", ruleId)
        startActivity(i)
    }

    private fun updateRandomEmptyState() {
        findViewById<View>(R.id.tvNoRandomRules).visibility = if (randomRules.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun updateRandomMasterUi(running: Boolean) {
        switchRandomMaster.setOnCheckedChangeListener(null)
        switchRandomMaster.isChecked = running
        tvRandomStatus.text = if (running) "▶ Running" else "⏸ Stopped"
        switchRandomMaster.setOnCheckedChangeListener { _, checked -> if (checked) startRandomAutomation() else stopRandomAutomation() }
    }

    private fun startRandomAutomation() {
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Accessibility service එක Enable කරන්න", Toast.LENGTH_LONG).show()
            resetRandomSwitch()
            openAccessibilitySettings()
            return
        }
        if (randomRules.none { it.enabled && it.points.isNotEmpty() }) {
            Toast.makeText(this, "අඩුම තරමින් point එකක් සහිත rule එකක් enable කරන්න", Toast.LENGTH_LONG).show()
            resetRandomSwitch()
            return
        }
        startForegroundServiceCompat(Intent(this, RandomClickService::class.java))
    }

    private fun resetRandomSwitch() {
        switchRandomMaster.setOnCheckedChangeListener(null)
        switchRandomMaster.isChecked = false
        switchRandomMaster.setOnCheckedChangeListener { _, checked -> if (checked) startRandomAutomation() else stopRandomAutomation() }
    }

    private fun stopRandomAutomation() {
        val i = Intent(this, RandomClickService::class.java).setAction(RandomClickService.ACTION_STOP)
        startService(i)
    }

    private fun openEditor(ruleId: String) {
        val i = Intent(this, RuleEditActivity::class.java)
        i.putExtra("ruleId", ruleId)
        startActivity(i)
    }

    private fun updateEmptyState() {
        findViewById<View>(R.id.tvNoRules).visibility = if (rules.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun updateMasterUi(running: Boolean) {
        switchMaster.setOnCheckedChangeListener(null)
        switchMaster.isChecked = running
        tvMasterStatus.text = if (running) "▶ Running" else "⏸ Stopped"
        switchMaster.setOnCheckedChangeListener { _, checked -> if (checked) startAutomation() else stopAutomation() }
    }

    private fun startAutomation() {
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Accessibility service එක Enable කරන්න", Toast.LENGTH_LONG).show()
            resetMasterSwitch()
            openAccessibilitySettings()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission එක දෙන්න", Toast.LENGTH_LONG).show()
            resetMasterSwitch()
            requestOverlayPermission()
            return
        }
        if (rules.none { it.enabled }) {
            Toast.makeText(this, "අඩුම තරමින් rule එකක් enable කරන්න", Toast.LENGTH_LONG).show()
            resetMasterSwitch()
            return
        }
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    /** Reset the master switch back to OFF without re-firing stopAutomation() (which would
     *  needlessly start+stop the capture service). */
    private fun resetMasterSwitch() {
        switchMaster.setOnCheckedChangeListener(null)
        switchMaster.isChecked = false
        switchMaster.setOnCheckedChangeListener { _, checked -> if (checked) startAutomation() else stopAutomation() }
    }

    private fun stopAutomation() {
        val i = Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP)
        startService(i)
    }

    private fun startForegroundServiceCompat(intent: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }

    // ---- permission rows ----

    private fun setupPermissionRow(includeId: Int, label: String, onGrant: () -> Unit) {
        val row = findViewById<View>(includeId)
        row.findViewById<TextView>(R.id.tvLabel).text = label
        row.findViewById<View>(R.id.btnGrant).setOnClickListener { onGrant() }
    }

    private fun refreshPermissionRows() {
        setRowStatus(R.id.rowAccessibility, isAccessibilityEnabled())
        setRowStatus(R.id.rowOverlay, Settings.canDrawOverlays(this))
        setRowStatus(R.id.rowCapture, EventBus.isRunning)
    }

    private fun setRowStatus(includeId: Int, ok: Boolean) {
        val row = findViewById<View>(includeId)
        row.findViewById<View>(R.id.dotStatus).setBackgroundResource(if (ok) R.drawable.dot_green else R.drawable.dot_red)
        row.findViewById<TextView>(R.id.btnGrant).text = if (ok) "OK" else "Grant"
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, TapAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun requestOverlayPermission() {
        val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        overlayLauncher.launch(i)
    }
}
