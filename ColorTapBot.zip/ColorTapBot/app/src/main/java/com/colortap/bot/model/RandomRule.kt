package com.colortap.bot.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * A "random clicker" rule: no color detection at all.
 * Every [intervalMs] the app randomly picks ONE of [points] and taps it.
 * The pick is independent every single time (true uniform random), so the same point
 * can repeat back to back, or alternate — never a fixed, predictable pattern.
 */
data class RandomRule(
    var id: String = UUID.randomUUID().toString(),
    var name: String = "Random Clicker",
    var enabled: Boolean = true,
    var points: MutableList<Pair<Int, Int>> = mutableListOf(),
    var intervalMs: Long = 3000
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("name", name)
        o.put("enabled", enabled)
        o.put("intervalMs", intervalMs)
        val arr = JSONArray()
        points.forEach { (x, y) ->
            val p = JSONObject(); p.put("x", x); p.put("y", y); arr.put(p)
        }
        o.put("points", arr)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): RandomRule {
            val r = RandomRule()
            r.id = o.optString("id", UUID.randomUUID().toString())
            r.name = o.optString("name", "Random Clicker")
            r.enabled = o.optBoolean("enabled", true)
            r.intervalMs = o.optLong("intervalMs", 3000)
            val arr = o.optJSONArray("points")
            val list = mutableListOf<Pair<Int, Int>>()
            if (arr != null) for (i in 0 until arr.length()) {
                val p = arr.getJSONObject(i)
                list.add(p.optInt("x", -1) to p.optInt("y", -1))
            }
            r.points = list
            return r
        }
    }
}
