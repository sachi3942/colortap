package com.colortap.bot.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import androidx.core.app.NotificationCompat
import com.colortap.bot.R
import com.colortap.bot.model.Rule
import com.colortap.bot.model.RuleState
import com.colortap.bot.ui.MainActivity
import com.colortap.bot.util.EventBus
import com.colortap.bot.util.PrefsManager

class ScreenCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private val ruleStates = mutableMapOf<String, RuleState>()
    private var running = false

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            androidx.core.app.ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification(),
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIF_ID, buildNotification())
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            return START_NOT_STICKY
        }
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data != null && resultCode != -1) {
            startCapture(resultCode, data)
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val channelId = "colortap_capture"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            if (mgr.getNotificationChannel(channelId) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(channelId, "ColorTap Bot", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("ColorTap Bot ක්‍රියාත්මකයි")
            .setContentText("Color detection running in background")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        if (running) return
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(resultCode, data)

        val metrics = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ColorTapCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        ruleStates.clear()
        PrefsManager.loadRules(this).filter { it.enabled }.forEach { r ->
            ruleStates[r.id] = RuleState(r)
        }

        thread = HandlerThread("ColorTapSampler").also { it.start() }
        handler = Handler(thread!!.looper)
        running = true
        EventBus.setRunning(true)
        EventBus.log("Screen capture started (${width}x$height)")
        scheduleSample()
    }

    private fun scheduleSample() {
        if (!running) return
        val interval = PrefsManager.globalSampleIntervalMs(this)
        handler?.postDelayed({
            sampleOnce()
            scheduleSample()
        }, interval)
    }

    private fun sampleOnce() {
        val reader = imageReader ?: return
        val image = try { reader.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val width = image.width

            for (state in ruleStates.values) {
                val rule = state.rule
                if (rule.detectX < 0 || rule.detectY < 0) continue
                if (rule.detectX >= image.width || rule.detectY >= image.height) continue
                val offset = rule.detectY * rowStride + rule.detectX * pixelStride
                if (offset + 3 >= buffer.capacity()) continue
                val r = buffer.get(offset).toInt() and 0xFF
                val g = buffer.get(offset + 1).toInt() and 0xFF
                val b = buffer.get(offset + 2).toInt() and 0xFF
                val color = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

                val action = state.onColorSampled(color)
                EventBus.log("${rule.name}: ${state.progressText}")
                if (action != null) {
                    EventBus.log(">> TAP x${action.tapCount} at (${action.x},${action.y}) [${rule.name}]")
                    TapAccessibilityService.instance?.performTaps(action.x, action.y, action.tapCount, action.intervalMs)
                        ?: EventBus.log("Accessibility service not enabled - cannot tap!")
                }
            }
        } catch (e: Exception) {
            EventBus.log("Sample error: ${e.message}")
        } finally {
            image.close()
        }
    }

    private fun stopCapture() {
        running = false
        EventBus.setRunning(false)
        EventBus.log("Screen capture stopped")
        handler?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        androidx.core.app.ServiceCompat.stopForeground(this, androidx.core.app.ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    companion object {
        const val NOTIF_ID = 4201
        const val ACTION_STOP = "com.colortap.bot.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
    }
}
