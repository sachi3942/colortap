package com.colortap.bot.service

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import androidx.core.app.NotificationCompat
import com.colortap.bot.R
import com.colortap.bot.ui.MainActivity
import com.colortap.bot.util.EventBus
import com.colortap.bot.util.PrefsManager
import kotlin.random.Random

class RandomClickService : Service() {

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var running = false

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopLoop()
            return START_NOT_STICKY
        }
        startLoop()
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val channelId = "colortap_random"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            if (mgr.getNotificationChannel(channelId) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(channelId, "ColorTap Bot - Random Clicker", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, RandomClickService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Random Clicker ක්‍රියාත්මකයි")
            .setContentText("Randomly tapping marked points")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun startLoop() {
        if (running) return
        running = true
        EventBus.setRandomRunning(true)
        EventBus.log("Random clicker started")
        thread = HandlerThread("RandomClickLoop").also { it.start() }
        handler = Handler(thread!!.looper)
        scheduleNext()
    }

    private fun scheduleNext() {
        if (!running) return
        val rules = PrefsManager.loadRandomRules(this).filter { it.enabled && it.points.isNotEmpty() }
        if (rules.isEmpty()) {
            EventBus.log("Random clicker: no enabled rule with points - stopping")
            stopLoop()
            return
        }
        // Each rule ticks independently but we drive them off one shared loop tick
        // using the shortest configured interval so every rule gets a chance to fire.
        val tick = rules.minOf { it.intervalMs }.coerceAtLeast(200)
        handler?.postDelayed({
            fireDueRules()
            scheduleNext()
        }, tick)
    }

    private val lastFire = mutableMapOf<String, Long>()

    private fun fireDueRules() {
        val now = System.currentTimeMillis()
        val rules = PrefsManager.loadRandomRules(this).filter { it.enabled && it.points.isNotEmpty() }
        for (rule in rules) {
            val last = lastFire[rule.id] ?: 0L
            if (now - last >= rule.intervalMs) {
                lastFire[rule.id] = now
                val point = rule.points[Random.nextInt(rule.points.size)]
                EventBus.log(">> RANDOM TAP [${rule.name}] at (${point.first},${point.second})")
                TapAccessibilityService.instance?.performTaps(point.first, point.second, 1, 0)
                    ?: EventBus.log("Accessibility service not enabled - cannot tap!")
            }
        }
    }

    private fun stopLoop() {
        running = false
        EventBus.setRandomRunning(false)
        EventBus.log("Random clicker stopped")
        handler?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        lastFire.clear()
        stopForegroundCompat()
        stopSelf()
    }

    private fun stopForegroundCompat() {
        androidx.core.app.ServiceCompat.stopForeground(this, androidx.core.app.ServiceCompat.STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        if (running) stopLoop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    companion object {
        const val NOTIF_ID = 4202
        const val ACTION_STOP = "com.colortap.bot.STOP_RANDOM"
    }
}
