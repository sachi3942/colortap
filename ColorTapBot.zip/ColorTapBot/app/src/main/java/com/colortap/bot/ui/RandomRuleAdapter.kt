package com.colortap.bot.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.colortap.bot.R
import com.colortap.bot.model.RandomRule
import com.google.android.material.switchmaterial.SwitchMaterial

class RandomRuleAdapter(
    private val rules: MutableList<RandomRule>,
    private val onEdit: (RandomRule) -> Unit,
    private val onDelete: (RandomRule) -> Unit,
    private val onToggle: (RandomRule, Boolean) -> Unit
) : RecyclerView.Adapter<RandomRuleAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvName: TextView = v.findViewById(R.id.tvName)
        val tvDetail: TextView = v.findViewById(R.id.tvDetail)
        val switchEnabled: SwitchMaterial = v.findViewById(R.id.switchEnabled)
        val btnEdit: TextView = v.findViewById(R.id.btnEdit)
        val btnDelete: TextView = v.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_random_rule, parent, false)
        return VH(v)
    }

    override fun getItemCount() = rules.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val rule = rules[position]
        holder.tvName.text = rule.name
        val seconds = rule.intervalMs / 1000.0
        holder.tvDetail.text = "${rule.points.size} points · every ${seconds}s · random pick"

        holder.switchEnabled.setOnCheckedChangeListener(null)
        holder.switchEnabled.isChecked = rule.enabled
        holder.switchEnabled.setOnCheckedChangeListener { _, checked -> onToggle(rule, checked) }

        holder.btnEdit.setOnClickListener { onEdit(rule) }
        holder.btnDelete.setOnClickListener { onDelete(rule) }
    }
}
