package com.colortap.bot.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.colortap.bot.R
import com.colortap.bot.model.RandomRule
import com.colortap.bot.service.PointPickerOverlayService
import com.colortap.bot.util.PrefsManager

class RandomRuleEditActivity : AppCompatActivity() {

    private lateinit var rule: RandomRule
    private lateinit var rules: MutableList<RandomRule>
    private lateinit var pointsAdapter: PointsAdapter
    private lateinit var stepperInterval: Stepper

    private val pointReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val mode = intent?.getStringExtra("mode") ?: return
            if (mode != "random") return
            val x = intent.getIntExtra("x", -1)
            val y = intent.getIntExtra("y", -1)
            rule.points.add(x to y)
            pointsAdapter.notifyItemInserted(rule.points.size - 1)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_random_edit)

        rules = PrefsManager.loadRandomRules(this)
        val ruleId = intent.getStringExtra("ruleId")
        rule = rules.find { it.id == ruleId } ?: RandomRule().also { rules.add(it) }

        findViewById<EditText>(R.id.etName).setText(rule.name)

        val recycler = findViewById<RecyclerView>(R.id.recyclerPoints)
        recycler.layoutManager = LinearLayoutManager(this)
        pointsAdapter = PointsAdapter(rule.points) { index ->
            rule.points.removeAt(index)
            pointsAdapter.notifyDataSetChanged()
        }
        recycler.adapter = pointsAdapter

        stepperInterval = Stepper(
            findViewById(R.id.stepperInterval),
            (rule.intervalMs / 1000).coerceAtLeast(1), 1, 3600, 1
        ) {}

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<View>(R.id.btnAddPoint).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Overlay permission එක මුලින්ම දෙන්න", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            Toast.makeText(this, "ටැප් වෙන්න ඕන තැනට මාක් එක ගෙනිහින් Set එබන්න", Toast.LENGTH_LONG).show()
            val i = Intent(this, PointPickerOverlayService::class.java)
            i.putExtra(PointPickerOverlayService.EXTRA_MODE, "random")
            i.putExtra(PointPickerOverlayService.EXTRA_RULE_ID, rule.id)
            startService(i)
        }

        findViewById<View>(R.id.btnSave).setOnClickListener { save() }

        LocalBroadcastManager.getInstance(this)
            .registerReceiver(pointReceiver, IntentFilter(PointPickerOverlayService.ACTION_POINT_PICKED))
    }

    override fun onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(pointReceiver)
        super.onDestroy()
    }

    private fun save() {
        rule.name = findViewById<EditText>(R.id.etName).text.toString().ifBlank { "Random Clicker" }
        rule.intervalMs = stepperInterval.get() * 1000

        if (rule.points.isEmpty()) {
            Toast.makeText(this, "අඩුම තරමින් tap point එකක් එකතු කරන්න", Toast.LENGTH_SHORT).show()
            return
        }

        if (rules.none { it.id == rule.id }) rules.add(rule)
        PrefsManager.saveRandomRules(this, rules)
        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        finish()
    }

    private class PointsAdapter(
        private val points: MutableList<Pair<Int, Int>>,
        private val onRemove: (Int) -> Unit
    ) : RecyclerView.Adapter<PointsAdapter.VH>() {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val label: TextView = v.findViewById(R.id.tvPointLabel)
            val remove: TextView = v.findViewById(R.id.btnRemove)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_point, parent, false)
            return VH(v)
        }

        override fun getItemCount() = points.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val (x, y) = points[position]
            holder.label.text = "Point ${position + 1}: x=$x, y=$y"
            holder.remove.setOnClickListener { onRemove(position) }
        }
    }
}
